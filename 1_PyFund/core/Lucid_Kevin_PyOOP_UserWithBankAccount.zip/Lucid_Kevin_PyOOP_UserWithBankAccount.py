from bankaccount import BankAccount


# User class
class User:
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.account = BankAccount(interest_ratae=0.02, balance=0)

    def display_user_info(self):
        print(self.name, "  ", self.email)
        self.account.display_account_info()

    def make_deposit(self, amount):
        print(self.name)
        self.account.deposit(amount)

    def make_withdrawal(self, amount):
        print(self.name)
        self.account.withdraw(amount)


user1 = User("Kevin Lucido", "kevinlucido@gmail.com")

user1.display_user_info()
