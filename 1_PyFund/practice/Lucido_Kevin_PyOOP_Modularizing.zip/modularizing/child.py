import parent

print(locals())
# import statement will run parent.py