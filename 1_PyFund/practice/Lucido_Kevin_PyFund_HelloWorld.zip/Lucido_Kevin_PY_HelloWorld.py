# 1
print("Hello World!")

# 2
myName = "Josh"
print("Hello", myName)

# 3
print("Hello " + myName)

# 4
favNum = 7
print("Hello", favNum)

# 5
print("Hello " + str(favNum))

# 6
food1 = "pasta"
food2 = "crepe"
print("I love to eat {} and {}!".format(food1, food2))

# 7
print(f"I love to eat {food1} and {food2}!")